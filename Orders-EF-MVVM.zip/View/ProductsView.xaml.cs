﻿namespace Orders.View
{
    public partial class ProductsView : System.Windows.Controls.UserControl
    {
        public ProductsView()
        {
            InitializeComponent();
        }
    }
}